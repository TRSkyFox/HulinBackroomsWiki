狐霖的後室 RPG — 紀錄包

這個壓縮檔只包含：
- session/：原始 logs、structured.jsonl
- staging/：已解析的樓層、實體、事件、evidence
- manifest.json：檔名、大小、sha256

Wiki 主人可用「匯入紀錄.bat」把 staging 併入 Wiki。
請不要把 Wiki content 放進這個壓縮檔。